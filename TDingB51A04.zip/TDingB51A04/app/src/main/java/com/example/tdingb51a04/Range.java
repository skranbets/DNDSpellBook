package com.example.tdingb51a04;

public class Range {
    private int rangeID;
    private String rangeName;

    public void setRangeID(int rangeID) {
        this.rangeID = rangeID;
    }

    public int getRangeID() {
        return rangeID;
    }

    public void setRangeName(String rangeName) {
        this.rangeName = rangeName;
    }

    public String getRangeName() {
        return rangeName;
    }
}
