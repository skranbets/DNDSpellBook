package com.example.tdingb51a04;

public class Duration {
    private int durationID;
    private String durationName;

    public void setDurationID(int durationID) {
        this.durationID = durationID;
    }

    public int getDurationID() {
        return durationID;
    }

    public void setDurationName(String durationName) {
        this.durationName = durationName;
    }

    public String getDurationName() {
        return durationName;
    }
}
