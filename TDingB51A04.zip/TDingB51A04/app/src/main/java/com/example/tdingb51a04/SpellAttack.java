package com.example.tdingb51a04;

public class SpellAttack {
    private int spellAttackID;
    private String spellAttackName;

    public void setSpellAttackID(int spellAttackID) {
        this.spellAttackID = spellAttackID;
    }

    public int getSpellAttackID() {
        return spellAttackID;
    }

    public void setSpellAttackName(String spellAttackName) {
        this.spellAttackName = spellAttackName;
    }

    public String getSpellAttackName() {
        return spellAttackName;
    }
}
