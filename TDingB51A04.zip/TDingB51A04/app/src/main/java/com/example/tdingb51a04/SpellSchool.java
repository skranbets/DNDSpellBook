package com.example.tdingb51a04;

public class SpellSchool {
    private int spellSchoolID;
    private String spellSchoolName;

    public void setSpellSchoolID(int spellSchoolID) {
        this.spellSchoolID = spellSchoolID;
    }

    public int getSpellSchoolID() {
        return spellSchoolID;
    }

    public void setSpellSchoolName(String spellSchoolName) {
        this.spellSchoolName = spellSchoolName;
    }

    public String getSpellSchoolName() {
        return spellSchoolName;
    }
}
