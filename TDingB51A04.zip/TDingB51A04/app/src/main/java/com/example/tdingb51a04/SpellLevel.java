package com.example.tdingb51a04;

public class SpellLevel {
    private int spellLevelID;
    private String spellLevelName;

    public void setSpellLevelID(int spellLevelID) {
        this.spellLevelID = spellLevelID;
    }

    public int getSpellLevelID() {
        return spellLevelID;
    }

    public void setSpellLevelName(String spellLevelName) {
        this.spellLevelName = spellLevelName;
    }

    public String getSpellLevelName() {
        return spellLevelName;
    }
}
