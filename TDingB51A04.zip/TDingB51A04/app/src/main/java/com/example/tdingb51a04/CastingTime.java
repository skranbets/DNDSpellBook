package com.example.tdingb51a04;

public class CastingTime {
    private int castingTimeID;
    private String castingTimeName;

    public void setCastingTimeID(int castingTimeID) {
        this.castingTimeID = castingTimeID;
    }

    public int getCastingTimeID() {
        return castingTimeID;
    }

    public void setCastingTimeName(String castingTimeName) {
        this.castingTimeName = castingTimeName;
    }

    public String getCastingTimeName() {
        return castingTimeName;
    }
}
