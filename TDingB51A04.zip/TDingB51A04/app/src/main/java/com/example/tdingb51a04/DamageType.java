package com.example.tdingb51a04;

public class DamageType {
    private int damageTypeID;
    private String damageTypeName;

    public void setDamageTypeID(int damageTypeID) {
        this.damageTypeID = damageTypeID;
    }

    public int getDamageTypeID() {
        return damageTypeID;
    }

    public void setDamageTypeName(String damageTypeName) {
        this.damageTypeName = damageTypeName;
    }

    public String getDamageTypeName() {
        return damageTypeName;
    }
}
